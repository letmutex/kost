package kotlin.collections
fun <T> listOf(vararg elements: T): List<T> = emptyList()
