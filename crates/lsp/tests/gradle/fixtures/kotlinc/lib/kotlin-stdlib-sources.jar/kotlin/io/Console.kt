package kotlin.io
fun println(message: Any?) {}
