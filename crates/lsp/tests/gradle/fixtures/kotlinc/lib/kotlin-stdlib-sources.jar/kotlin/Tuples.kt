package kotlin
/**
 * Represents a generic pair of two values.
 *
 * @param first The first value.
 * @param second The second value.
 */
data class Pair<out A, out B>(
    val first: A,
    val second: B
)
