package androidx.annotation

annotation class CheckResult(val suggest: String = "")
