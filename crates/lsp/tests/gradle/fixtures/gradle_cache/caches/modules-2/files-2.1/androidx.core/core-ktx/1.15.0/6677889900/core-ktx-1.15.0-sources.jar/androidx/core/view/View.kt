package androidx.core.view
fun isNewKtxVersion(): Boolean = true
fun isVisible(): Boolean = true
