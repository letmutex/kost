package androidx.annotation

/**
 * Denotes that a parameter, field or method return value can never be null.
 */
annotation class NonNull
