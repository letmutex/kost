package androidx.core.view
fun isOldKtxVersion(): Boolean = true
